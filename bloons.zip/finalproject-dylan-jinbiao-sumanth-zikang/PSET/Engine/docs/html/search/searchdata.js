var indexSectionsWithContent =
{
  0: "begiprstw",
  1: "begiprstw",
  2: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files"
};

