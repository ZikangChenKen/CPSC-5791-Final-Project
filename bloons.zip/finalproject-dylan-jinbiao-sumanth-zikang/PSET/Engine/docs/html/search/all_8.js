var searchData=
[
  ['wavecanvas_0',['WaveCanvas',['../classcanvas_1_1wavecanvas_1_1_wave_canvas.html',1,'canvas::wavecanvas']]],
  ['waveeditor_1',['WaveEditor',['../classeditor_1_1waveeditor_1_1_wave_editor.html',1,'editor::waveeditor']]]
];
